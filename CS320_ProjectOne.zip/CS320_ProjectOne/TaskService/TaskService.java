package taskservice;

import java.util.HashMap;
import java.util.Map;

/**
 * TaskService.java
 *
 * Author: Hilnecia Larry
 * Course: CS 320
 * Description: Stores tasks in memory and provides add, delete, and update services.
 */
public class TaskService {

    // In-memory storage (no database required)
    private final Map<String, Task> taskMap = new HashMap<>();

    /**
     * Adds a task with a unique ID.
     * Throws IllegalArgumentException if the task is null or the ID already exists.
     */
    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null.");
        }

        String id = task.getTaskId();
        if (taskMap.containsKey(id)) {
            throw new IllegalArgumentException("Task ID already exists.");
        }

        taskMap.put(id, task);
    }

    /**
     * Deletes a task by task ID.
     * Throws IllegalArgumentException if the ID does not exist.
     */
    public void deleteTask(String taskId) {
        if (!taskMap.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID does not exist.");
        }

        taskMap.remove(taskId);
    }

    /**
     * Updates task fields by task ID.
     * Updatable fields: name, description
     *
     * If name or description is null, that field is not changed.
     * Throws IllegalArgumentException if the task ID does not exist.
     */
    public void updateTask(String taskId, String name, String description) {
        Task task = taskMap.get(taskId);

        if (task == null) {
            throw new IllegalArgumentException("Task ID does not exist.");
        }

        if (name != null) {
            task.setName(name);
        }

        if (description != null) {
            task.setDescription(description);
        }
    }

    /**
     * Helper method for tests (not required by rubric, but useful).
     */
    public Task getTask(String taskId) {
        return taskMap.get(taskId);
    }
}
