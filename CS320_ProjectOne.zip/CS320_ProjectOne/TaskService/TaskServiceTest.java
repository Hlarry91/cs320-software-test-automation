package taskservice;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * TaskServiceTest.java
 *
 * Author: Hilnecia Larry
 * Course: CS 320
 * Description: Unit tests for TaskService class using JUnit 5.
 */
public class TaskServiceTest {

    @Test
    void testAddTaskSuccessfully() {
        TaskService service = new TaskService();
        Task task = new Task("12345", "Task name", "Task description");

        service.addTask(task);

        assertNotNull(service.getTask("12345"));
        assertEquals("Task name", service.getTask("12345").getName());
    }

    @Test
    void testAddTaskFailsForDuplicateId() {
        TaskService service = new TaskService();
        Task task1 = new Task("12345", "Task name", "Task description");
        Task task2 = new Task("12345", "Another name", "Another description");

        service.addTask(task1);

        assertThrows(IllegalArgumentException.class, () -> service.addTask(task2));
    }

    @Test
    void testDeleteTaskSuccessfully() {
        TaskService service = new TaskService();
        Task task = new Task("12345", "Task name", "Task description");

        service.addTask(task);
        service.deleteTask("12345");

        assertNull(service.getTask("12345"));
    }

    @Test
    void testDeleteTaskFailsIfIdDoesNotExist() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("99999"));
    }

    @Test
    void testUpdateTaskNameOnly() {
        TaskService service = new TaskService();
        Task task = new Task("12345", "Old name", "Old description");

        service.addTask(task);
        service.updateTask("12345", "New name", null);

        assertEquals("New name", service.getTask("12345").getName());
        assertEquals("Old description", service.getTask("12345").getDescription());
    }

    @Test
    void testUpdateTaskDescriptionOnly() {
        TaskService service = new TaskService();
        Task task = new Task("12345", "Old name", "Old description");

        service.addTask(task);
        service.updateTask("12345", null, "New description");

        assertEquals("Old name", service.getTask("12345").getName());
        assertEquals("New description", service.getTask("12345").getDescription());
    }

    @Test
    void testUpdateTaskFailsIfIdDoesNotExist() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class,
                () -> service.updateTask("99999", "Name", "Description"));
    }
}
