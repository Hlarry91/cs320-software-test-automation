package taskservice;

/**
 * Task.java
 *
 * Author: Hilnecia Larry
 * Course: CS 320
 * Description: Task object with required fields and basic validation.
 */
public class Task {

    private final String taskId;     // not updatable
    private String name;
    private String description;

    /**
     * Creates a Task with required fields.
     *
     * Requirements enforced:
     * - taskId: required, <= 10 chars, not updatable
     * - name: required, <= 20 chars
     * - description: required, <= 50 chars
     */
    public Task(String taskId, String name, String description) {
        validateTaskId(taskId);
        validateName(name);
        validateDescription(description);

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    // -------------------- Validation Helpers --------------------

    private void validateTaskId(String value) {
        if (value == null || value.length() > 10) {
            throw new IllegalArgumentException("Task ID must not be null and must be 10 characters or less.");
        }
    }

    private void validateName(String value) {
        if (value == null || value.length() > 20) {
            throw new IllegalArgumentException("Name must not be null and must be 20 characters or less.");
        }
    }

    private void validateDescription(String value) {
        if (value == null || value.length() > 50) {
            throw new IllegalArgumentException("Description must not be null and must be 50 characters or less.");
        }
    }

    // -------------------- Getters / Setters --------------------

    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        validateName(name);
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        validateDescription(description);
        this.description = description;
    }
}
