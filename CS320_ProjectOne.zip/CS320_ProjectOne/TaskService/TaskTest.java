package taskservice;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * TaskTest.java
 *
 * Author: Hilnecia Larry
 * Course: CS 320
 * Description: Unit tests for Task class using JUnit 5.
 */
public class TaskTest {

    @Test
    void testTaskCreatesSuccessfully() {
        Task task = new Task("12345", "Do homework", "Finish CS 320 milestone");
        assertEquals("12345", task.getTaskId());
        assertEquals("Do homework", task.getName());
        assertEquals("Finish CS 320 milestone", task.getDescription());
    }

    @Test
    void testTaskIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task(null, "Name", "Description"));
    }

    @Test
    void testTaskIdCannotBeLongerThan10() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("12345678901", "Name", "Description"));
    }

    @Test
    void testNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("12345", null, "Description"));
    }

    @Test
    void testNameCannotBeLongerThan20() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("12345", "123456789012345678901", "Description"));
    }

    @Test
    void testDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("12345", "Name", null));
    }

    @Test
    void testDescriptionCannotBeLongerThan50() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("12345", "Name",
                        "123456789012345678901234567890123456789012345678901"));
    }
}
