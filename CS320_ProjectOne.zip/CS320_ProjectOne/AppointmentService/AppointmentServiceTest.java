package appointmentservice;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

/**
 * AppointmentServiceTest.java
 * Unit tests for AppointmentService class.
 *
 * Author: Hilnecia Larry
 * Date: 2026-02-08
 */
public class AppointmentServiceTest {

    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 86_400_000L); // +1 day
    }

    @Test
    void testAddAppointmentSuccess() {
        AppointmentService service = new AppointmentService();
        Appointment appt = new Appointment("A1", futureDate(), "Consult");

        service.addAppointment(appt);

        assertNotNull(service.getAppointment("A1"));
        assertEquals("A1", service.getAppointment("A1").getAppointmentId());
    }

    @Test
    void testAddAppointmentDuplicateIdThrows() {
        AppointmentService service = new AppointmentService();

        Appointment appt1 = new Appointment("A1", futureDate(), "Consult");
        Appointment appt2 = new Appointment("A1", futureDate(), "Follow-up");

        service.addAppointment(appt1);

        assertThrows(IllegalArgumentException.class, () ->
            service.addAppointment(appt2)
        );
    }

    @Test
    void testDeleteAppointmentSuccess() {
        AppointmentService service = new AppointmentService();
        Appointment appt = new Appointment("A1", futureDate(), "Consult");

        service.addAppointment(appt);
        service.deleteAppointment("A1");

        assertNull(service.getAppointment("A1"));
    }

    @Test
    void testDeleteAppointmentNotFoundThrows() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () ->
            service.deleteAppointment("DOESNOTEXIST")
        );
    }

    @Test
    void testDeleteAppointmentNullIdThrows() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () ->
            service.deleteAppointment(null)
        );
    }
}