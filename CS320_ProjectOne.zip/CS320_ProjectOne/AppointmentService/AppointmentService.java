package appointmentservice;

import java.util.HashMap;
import java.util.Map;

/**
 * AppointmentService.java
 * CS-320 Software Test Automation QA
 *
 * In-memory service for adding and deleting appointments.
 * Requirements:
 * - Add appointments with a unique appointment ID
 * - Delete appointments per appointment ID
 *
 * Author: Hilnecia Larry
 * Date: 2026-02-08
 */
public class AppointmentService {

    private final Map<String, Appointment> appointments = new HashMap<>();

    /**
     * Adds an appointment. Appointment IDs must be unique.
     */
    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment must not be null.");
        }

        String id = appointment.getAppointmentId();
        if (appointments.containsKey(id)) {
            throw new IllegalArgumentException("Appointment ID already exists: " + id);
        }

        appointments.put(id, appointment);
    }

    /**
     * Deletes an appointment by appointmentId.
     */
    public void deleteAppointment(String appointmentId) {
        if (appointmentId == null || appointmentId.trim().isEmpty()) {
            throw new IllegalArgumentException("Appointment ID must not be null/empty.");
        }

        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("No appointment found with ID: " + appointmentId);
        }

        appointments.remove(appointmentId);
    }

    /**
     * Helper method for testing/verification (not required by rubric but useful).
     */
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}
