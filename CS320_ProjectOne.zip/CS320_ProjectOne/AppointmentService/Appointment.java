package appointmentservice;

import java.util.Date;

/**
 * Appointment.java
 * CS-320 Software Test Automation QA
 *
 * Represents an appointment object with validation rules:
 * - appointmentId: required, not null, <= 10 chars, not updatable
 * - appointmentDate: required, not null, not in the past
 * - description: required, not null, <= 50 chars
 *
 * Author: Hilnecia Larry
 * Date: 2026-02-08
 */
public class Appointment {

    private final String appointmentId;   // not updatable
    private Date appointmentDate;
    private String description;

    public Appointment(String appointmentId, Date appointmentDate, String description) {
        // Validate appointmentId
        if (appointmentId == null || appointmentId.trim().isEmpty()) {
            throw new IllegalArgumentException("Appointment ID must not be null/empty.");
        }
        if (appointmentId.length() > 10) {
            throw new IllegalArgumentException("Appointment ID must not be longer than 10 characters.");
        }

        // Validate appointmentDate
        if (appointmentDate == null) {
            throw new IllegalArgumentException("Appointment date must not be null.");
        }
        // "Cannot be in the past"
        if (appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date must not be in the past.");
        }

        // Validate description
        if (description == null || description.trim().isEmpty()) {
            throw new IllegalArgumentException("Description must not be null/empty.");
        }
        if (description.length() > 50) {
            throw new IllegalArgumentException("Description must not be longer than 50 characters.");
        }

        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    // Getters
    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public String getDescription() {
        return description;
    }

    // Setters (ID intentionally has NO setter)
    public void setAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null) {
            throw new IllegalArgumentException("Appointment date must not be null.");
        }
        if (appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date must not be in the past.");
        }
        this.appointmentDate = appointmentDate;
    }

    public void setDescription(String description) {
        if (description == null || description.trim().isEmpty()) {
            throw new IllegalArgumentException("Description must not be null/empty.");
        }
        if (description.length() > 50) {
            throw new IllegalArgumentException("Description must not be longer than 50 characters.");
        }
        this.description = description;
    }
}