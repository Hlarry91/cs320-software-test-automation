package appointmentservice;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

/**
 * AppointmentTest.java
 * Unit tests for Appointment class.
 *
 * Author: Hilnecia Larry
 * Date: 2026-02-08
 */
public class AppointmentTest {

    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 86_400_000L); // +1 day
    }

    private Date pastDate() {
        return new Date(System.currentTimeMillis() - 86_400_000L); // -1 day
    }

    @Test
    void testCreateValidAppointment() {
        Appointment appt = new Appointment("A123", futureDate(), "Routine check-in");
        assertEquals("A123", appt.getAppointmentId());
        assertNotNull(appt.getAppointmentDate());
        assertEquals("Routine check-in", appt.getDescription());
    }

    // ---- Appointment ID tests ----
    @Test
    void testAppointmentIdNullThrows() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(null, futureDate(), "Desc")
        );
    }

    @Test
    void testAppointmentIdTooLongThrows() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("12345678901", futureDate(), "Desc") // 11 chars
        );
    }

    // ---- Date tests ----
    @Test
    void testAppointmentDateNullThrows() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("A123", null, "Desc")
        );
    }

    @Test
    void testAppointmentDateInPastThrows() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("A123", pastDate(), "Desc")
        );
    }

    // ---- Description tests ----
    @Test
    void testDescriptionNullThrows() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("A123", futureDate(), null)
        );
    }

    @Test
    void testDescriptionTooLongThrows() {
        String longDesc = "123456789012345678901234567890123456789012345678901"; // 51
        assertEquals(51, longDesc.length());

        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("A123", futureDate(), longDesc)
        );
    }

    @Test
    void testUpdateDescriptionValid() {
        Appointment appt = new Appointment("A123", futureDate(), "Old");
        appt.setDescription("New description");
        assertEquals("New description", appt.getDescription());
    }

    @Test
    void testUpdateDateValid() {
        Appointment appt = new Appointment("A123", futureDate(), "Desc");
        Date newerFuture = new Date(System.currentTimeMillis() + 172_800_000L); // +2 days
        appt.setAppointmentDate(newerFuture);
        assertEquals(newerFuture, appt.getAppointmentDate());
    }

    @Test
    void testUpdateDateToPastThrows() {
        Appointment appt = new Appointment("A123", futureDate(), "Desc");
        assertThrows(IllegalArgumentException.class, () ->
            appt.setAppointmentDate(pastDate())
        );
    }
}
