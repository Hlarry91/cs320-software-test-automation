package contactservice;

/**
 * Contact.java
 * Author: Hilnecia Larry
 * Course: CS 320
 * Description: Contact object with required fields and basic validation.
 */
public class Contact {

    private final String contactId; // Not updatable
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        validateId(contactId);
        validateName(firstName, "First name");
        validateName(lastName, "Last name");
        validatePhone(phone);
        validateAddress(address);

        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }

    private void validateId(String value) {
        if (value == null || value.length() > 10) {
            throw new IllegalArgumentException("Contact ID must not be null and must be 10 characters or less.");
        }
    }

    private void validateName(String value, String fieldName) {
        if (value == null || value.length() > 10) {
            throw new IllegalArgumentException(fieldName + " must not be null and must be 10 characters or less.");
        }
    }

    private void validatePhone(String value) {
        if (value == null || !value.matches("\\d{10}")) {
            throw new IllegalArgumentException("Phone must not be null and must be exactly 10 digits.");
        }
    }

    private void validateAddress(String value) {
        if (value == null || value.length() > 30) {
            throw new IllegalArgumentException("Address must not be null and must be 30 characters or less.");
        }
    }

    public String getContactId() {
        return contactId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        validateName(firstName, "First name");
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        validateName(lastName, "Last name");
        this.lastName = lastName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        validatePhone(phone);
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        validateAddress(address);
        this.address = address;
    }
}