package contactservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 * ContactTest.java
 * Author: Hilnecia Larry
 * Course: CS 320
 * Description: Unit tests for Contact class using JUnit 5.
 */
public class ContactTest {

    @Test
    void testContactCreatesSuccessfully() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main Street");
        assertEquals("12345", contact.getContactId());
    }

    @Test
    void testContactIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact(null, "John", "Doe", "1234567890", "123 Main Street"));
    }

    @Test
    void testFirstNameCannotBeLongerThan10() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345", "VeryLongName", "Doe", "1234567890", "123 Main Street"));
    }

    @Test
    void testLastNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345", "John", null, "1234567890", "123 Main Street"));
    }

    @Test
    void testPhoneMustBeExactly10Digits() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345", "John", "Doe", "12345", "123 Main Street"));
    }

    @Test
    void testAddressCannotBeLongerThan30() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345", "John", "Doe", "1234567890",
                        "This address is definitely way too long"));
    }

    @Test
    void testSettersUpdateFields() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main Street");
        contact.setFirstName("Jane");
        contact.setLastName("Smith");
        contact.setPhone("0987654321");
        contact.setAddress("456 Oak Street");

        assertEquals("Jane", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("0987654321", contact.getPhone());
        assertEquals("456 Oak Street", contact.getAddress());
    }
}